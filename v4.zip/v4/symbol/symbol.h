#ifndef SYMBOL_H
#define SYMBOL_H

extern char *symbol_new_symbol(void);
#endif
#ifndef SUITE_H
#define SUITE_H
extern void suite_e_suite(int longueur);
#endif